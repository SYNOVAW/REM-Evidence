#!/usr/bin/env python3
print("Replay stub: provide audit JSONL line to your runtime")
